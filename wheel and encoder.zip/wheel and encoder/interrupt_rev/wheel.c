/*
 * wheel.c
 *
 *  Created on: 28 Oct 2019
 *      Author: adilah
 */

#include <wheel.h>

uint16_t AIN1; //p4.2
uint16_t AIN2; //p4.3
uint16_t BIN1; //p4.5
uint16_t BIN2; //p4.7
uint16_t PWM1; //p4.1
uint16_t PWM2; //p4.6
uint16_t STBY; //p4.4


//STBY MUST BE 1 FOR MOTORS TO MOVE

void init_wheel(uint16_t inputL, uint16_t inputR,uint16_t inputAL, uint16_t inputAR,uint16_t pwma,uint16_t pwmb,uint16_t stby){
    AIN1=inputAL;
    AIN2=inputAR;
    BIN1=inputL;
    BIN2=inputR;
    PWM1=pwma;
    PWM2=pwmb;
    STBY=stby;

    P4DIR=0;
    P4OUT=0;
    P4DIR |=AIN1+AIN2+BIN1+BIN2+PWM1+PWM2+STBY;



}

void forward(){
    P4OUT |= STBY+AIN1+PWM1+BIN2+PWM2;
    P4OUT &=~AIN2+~BIN1;




    //in1 in2 pwm out1 out2
    //H   L    H-> H   L   => MOVE FORWARD

}
void forwardlp(){
    P4OUT |= STBY+AIN1+BIN2;
    P4OUT &=~AIN2+~BIN1+~PWM2;
//    P4OUT =




    //in1 in2 pwm out1 out2
    //H   L    H-> H   L   => MOVE FORWARD

}

void backward(){

    P4OUT |= STBY+AIN2+PWM1+BIN1+PWM2;
    P4OUT &=~AIN1+~BIN2;


    //in1 in2 pwm out1 out2
    //L   H    H-> L   H   => MOVE BACKWARD

}

void turnright(){
    P4OUT |= STBY+AIN1+PWM1+BIN1+PWM2;
    P4OUT &=~AIN2+~BIN2;


    //in1 in2 pwm out1 out2
    //L   H    H-> L   H

    //in1 in2 pwm out1 out2
    //H   L    H-> H   L
    //EACH WHEEL TURN DIFF DIRECTION

}

void turnleft(){
    P4OUT |= STBY+AIN2+PWM1+BIN2+PWM2;
    P4OUT &=~AIN1+~BIN1;


    //in1 in2 pwm out1 out2
    //H   L    H-> H   L

    //in1 in2 pwm out1 out2
    //L   H    H-> L   H
    //EACH WHEEL TURN DIFF DIRECTION

}

void stop(){

    P4OUT |= PWM1+PWM2+BIN1+BIN2;
    P4OUT &=~AIN2+~AIN1+~STBY;

    //in1 in2 pwm out1 out2
    //L   L    H-> OFF   OFF
}
