#include "msp.h"
#include "encoder.h"
#include "wheel.h"
#define N1 60000
#define N2 45000
#define N3 60000


/**
 * main.c
 */
void TimerA0_Init(void);
void TA0_N_IRQHandler(void);
void delayMs(int n);

float encoder_speed=0.0;


void main(void)

{
	WDT_A->CTL = WDT_A_CTL_PW | WDT_A_CTL_HOLD;		// stop watchdog timer
	P4DIR=0;
	P4OUT=0;
	P1DIR=0;
	P1OUT=0;
	P2DIR=0;
	P2OUT=0;


	P1DIR |= BIT0;
	TimerA0_Init();
	encoder_init();
	init_wheel( BIT5,  BIT7, BIT2,  BIT3, BIT1, BIT6, BIT4);

	forward();
    delayMs(6000);
    stop();

    backward();
    delayMs(6000);
    stop();
    turnright();
    delayMs(6000);
    stop();
    turnleft();
    delayMs(6000);
    stop();




}

void TimerA0_Init(void){
    TA0CTL &= ~0x0030; //halttimer
    TA0CTL = 0x0240; //smlk divide by 2
    TA0EX0 = 0x0007; // divide by 6
    TA0CCTL1 = 0x0010;  //compare mode
    TA0CCR1 = N1;

    NVIC->ISER[0]=0x00000200;  //enable interrupt
    TA0CTL|=0x0024;

}


void TA0_N_IRQHandler(void){
    if(TA0CCTL1&0x0001){
        TA0CCTL1&=~0x0001;  //acknowledge
        TA0CCR1 = TA0CCR1+N1;  //set time
        P1OUT^=BIT0;   //blink the led
        encoder_speed=getSpeed();  //get the speed
    }

}

void delayMs(int n)
{
    int i;

    TIMER32_1->LOAD = 3000 - 1;
    TIMER32_1->CONTROL = 0xC2; //- register T32, bit 1100 0010,

    for(i = 0; i < n; i++) {
        while((TIMER32_1->RIS & 1) == 0); /* wait until the RAW_IFG is set  - start from 2999, starts counting until 0*/
        TIMER32_1->INTCLR = 0;            /* clear RAW_IFG flag  - once it hits 0, the flag will go down. clear the flag*/
    }
}


